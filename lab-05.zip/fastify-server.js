const fastify = require('fastify');

// Create a Fastify instance
const app = fastify();

// Array of students
const students = [
    {
      id: 1,
      last: "Last1",
      first: "First1",
    },
    {
      id: 2,
      last: "Last2",
      first: "First2",
    },
    {
      id: 3,
      last: "Last3",
      first: "First3",
    }
  ];
// GET /cit/student - Return all students
app.get('/cit/student', (request, reply) => {
  reply.code(200).send(students);
});

// GET /cit/student/:id - Return a single student by ID
app.get('/cit/student/:id', (request, reply) => {
  const id = parseInt(request.params.id);
  const student = students.find(student => student.id === id);

  if (student) {
    reply.code(200).send(student);
  } else {
    reply.code(404).send('Not Found');
  }
});

// Unmatched route handler
app.setNotFoundHandler((request, reply) => {
  reply.code(404).send('Not Found');
});

// Start the server
const start = async () => {
    try {
      await app.listen({ port: 3000 });
      console.log('Server started on port 3000');
    } catch (err) {
      console.error(err);
      process.exit(1);
    }
  };

start();

let nextId = students.length + 1;

// POST /cit/student - Add a new student
app.post('/cit/student', (request, reply) => {
  const { last, first } = request.body;

  const newStudent = {
    id: nextId++,
    last,
    first,
  };

  students.push(newStudent);

  reply.code(201).send(newStudent);
});

